<?php
defined('BASEPATH') or exit('No direct script access allowed');

class User extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->model('Buku_model');
    }

    public function index()
    {
        $data1['buku'] = $this->Buku_model->getAllBuku('buku');
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();
        $this->load->view('user/home', $data1);
    }

    public function tambah()
    {
        $this->load->view('user/tambah');
    }


    public function create()
    {
        $this->Buku_model->tambahDataBuku();
    }



    public function hapus($id)
    {
        $this->Buku_model->hapusDataBuku($id);
        $this->session->set_flashdata('flash', 'Dihapus');
        redirect('user');
    }
}