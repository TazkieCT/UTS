<?php

class Buku_model extends CI_Model
{
    public function getAllBuku()
    {
        return $this->db->get('buku')->result_array();
    }

    public function hapusDataBuku($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('buku');
    }

    public function tambahDataBuku()
    {
        $data = [
            'nama' => $this->input->post('name'),
            'pengarang' => $this->input->post('pengarang'),
            'halaman' => $this->input->post('halaman'),
            'gambar' => $this->input->post('gambar'),
        ];

        $this->db->insert('buku', $data);
        redirect('user');
    }
}